# ABNTexUFPR

## Boas-vindas ao Git do ABNTexUTFPR!

O template ABNTexUTFPR foi criado para auxiliar pessoas a estruturarem, escreverem e organizarem TCCs, Dissertações e Teses em um projeto LaTeX, e por meio dele gerarem um PDF no formato exigido pela biblioteca da UTFPR.

Esse repositório é organizado para que as pessoas que desejam utilizar o template ABNTexUTFPR, tenham acesso à informações básicas sobre:

	* Instalação do LaTeX;
	* Estrutura básica de documentos LaTeX;
	* Comandos recorrentes em documentos LaTeX;
	* Template ABNTexUTFPR;
	* Sites com informações interessantes com comandos e dicas para LaTeX.

As informações desse repositório podem ser atualizadas com frequência ou demorarem bastante, isso depende de tempo e disponibilidade das pessoas envolvidas.

É importante ressaltar que o conteúdo desse repositório é gratuito, mas as pessoas envolvidas em sua organização, não assumem ou assumirão qualquer responsabilidade pelo uso do conteúdo aqui disponibilizado.

De todo modo, espero que os dados desse repositório possam lhe ajudar em seus trabalhos com LaTeX.

Abraços o/
